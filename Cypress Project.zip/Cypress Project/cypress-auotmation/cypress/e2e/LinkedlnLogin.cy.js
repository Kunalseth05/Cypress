describe("Successfully Application Login",()=>{
    beforeEach(()=>{
        cy.visit("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    });
    function validLoginIntoApplication(username,password){
        cy.screenshot("Landed on Home Page")
        //cy.xpath("//a[@class='nav__button-secondary btn-secondary-emphasis btn-md']").click();
        cy.wait(2000);
        cy.xpath("//input[@name='username']").type(username);
        cy.xpath("//input[@name='password']").type(password);
        cy.screenshot("Entered User ID and Password");
        cy.xpath("//button[@type='submit']").click();
        cy.xpath("//h6['Dashboard']").should('exist');
        cy.screenshot("Valid User Login");

    };

    it("Should successfully validate the valid login user", ()=>{
        validLoginIntoApplication("Admin","admin123")
    });

    it("Should not validate the invalid login user", ()=>{
            validLoginIntoApplication("Admin","hi")
        });
});
