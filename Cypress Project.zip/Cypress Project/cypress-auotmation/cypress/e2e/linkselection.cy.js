describe("Link Selection", ()=>{
    function onclick(linkname){
        cy.visit("https://www.hmrc.gov.uk");
        cy.screenshot("Home Page")
        cy.xpath("//ul[@class='gem-c-list govuk-list govuk-list--spaced']//li//a[contains(text(),'"+ linkname +"')]").click();
        cy.screenshot("Validate Service Page")
    }

    function validateservices(){
        cy.xpath("//li[not(a) and not(@class)]").each(($el,index)=>{
            cy.log('List of Services you can use with your HMRC online account ${index + 1}: ${$el.text().trim()}' );
        });
    };

    it("Should click on the link which we are passing at the run time", ()=>{
        onclick("HMRC online - sign in or set up");
        cy.wait(3000);
        validateservices();
    });
});
