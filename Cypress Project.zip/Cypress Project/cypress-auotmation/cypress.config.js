const { defineConfig } = require("cypress");
module.exports = defineConfig({
  e2e: {
    baseUrl: "https://www.hmrc.gov.uk",
    defaultCommandTimeout: 5000,
    pageLoadTimeout: 10000,
    browser: "chrome",
    headless: false,
    reporter: "mochawesome", // Use mochawesome as the reporter
    reporterOptions: {
      reportDir: "cypress/results",  // Set the report directory
      overwrite: true,               // Overwrite reports if they exist
      html: true,                    // Generate HTML report
      json: true                     // Generate JSON report
    },
    screenshotOnRunFailure: true,    // Capture all screenshots on failure
    screenshotFolder: "cypress/screenshots", // Folder for storing screenshots
    setupNodeEvents(on, config) {
      // Add custom listener to handle failed tests
      on('after:screenshot', (details) => {
        if (details.path.includes('failed')) {
         details.path = details.path;
        }
      });

      // Optional: For additional reporting functionality, you can log events or do other actions here
    },
  },
});